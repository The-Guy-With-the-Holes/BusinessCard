<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />

<meta name="description" content="Tyre Save Medina new and used tyres and wheels in medina rockingham kwinana calista orelia leda parmelia hillman wellard cooloongup casuarina anketell hope valley baldivis safety bay waikiki warnbro" />

<meta name="keywords" content="Tyre Save Medina new and used tyres and wheels in medina, rockingham, Perth, WA, western australia, kwinana, calista, orelia, leda, parmelia, hillman, wellard, cooloongup, casuarina, anketell, hope valley, baldivis, safety bay, waikiki, warnbro" />

<title>
</title>

<link rel="icon" type="image/vnd.microsoft.icon" href="favicon.ico" />

<link rel="SHORTCUT ICON" href="favicon.ico" />

<style type="text/css">
  html,body {margin: 0px; height: 100%; font-family: arial; font-size: 14px; color: #333333; background: #FFFFFF;}
  a {color: #000080; text-decoration: none; font-weight: bold;}
  a:hover {color: #ff0000; text-decoration: none;}
  hr {margin: 2px; padding: 0px; line-height: 2px; border: solid 1px #ff0000;}
  .main {border: solid 4px #000080; padding: 0px; min-width: 900px; min-height: 95%; display: block; position: relative;}
  .title1 {color: #000080; font-size: 18px; font-weight: bold;}
  .title2 {color: #000080; font-size: 14px; font-weight: bold;}
  .contact {text-align: right; vertical-align: bottom; padding: 5px; color: #000080; font-size: 14px;}
  .logo {padding: 5px;}
  .logos {padding: 5px; position: absolute; top: 10px; right: 10px;}
  .navtext {color: #ffffff; font-size: 12px; font-weight: bold;}
  .banner {color: #ffffff; font-size: 24px; font-weight: bold;}
  .headerbox {background: #ffff00; position: relative;}
  .navbox {background: #000080; border-top: solid 2px #ff0000; border-bottom: solid 2px #ff0000; padding: 5px;}
  .nav {color: #ffffff; background: #ff0000; font-size: 14px; font-weight: bold; margin: 2px; padding: 1px 8px 1px 8px; border: inset 1px #ffff00;}
  .nav:hover {background: #ffff00; color: #000080;}
  .navbot {color: #ffffff; font-size: 10px; font-weight: bold;}
  .navbot:hover {background: #ffff00; color: #000080;}
  .cop {color: #000000; font-size: 10px;}
  .cont {margin: 5px;}
  .box {margin: 5px; padding: 5px; border: solid 2px #000080;}
  .pic {margin: 5px; border: solid 1px #000080;}
  .bl {width: 16px; height: 16px; position: absolute; bottom: -1px; left: -1px;}
  .br {width: 16px; height: 16px; position: absolute; bottom: -1px; right: -1px;}
  .tl {width: 16px; height: 16px; position: absolute; top: -1px; left: -1px; z-index: 999;}
  .tr {width: 16px; height: 16px; position: absolute; top: -1px; right: -1px; z-index: 999;}

</style>

</head>
<body>

<!-- main div for page border -->

<div class="main">
<img src="tl.png" class="tl" alt="spacer" />
<img src="tr.png" class="tr" alt="spacer"/><img src="bl.png" class="bl" alt="spacer"/>
<img src="br.png" class="br" alt="spacer"/>

<!-- header table -->

<table width="100%" border="0" cellpadding="0" cellspacing="0">

<tr>
<td class="headerbox">

<img src="logoweb.png" class="logo" alt="Tyre Save Medina" border="0" width="279" height="120" />
</td><td class="headerbox">&nbsp;&nbsp;&nbsp;</td><td class="headerbox">

<!-- banner -->
<br/><br/><img src="new-used-tyres-low-price-great-service.png" alt="new and used tyres, low price, great service"/>
&nbsp;&nbsp;&nbsp;<img src="dymatech-mechanical.png" alt="Dymatech Mechanical" /><br/>
<br/>

<div class="contact">4 Seabrook Way, Medina, WA 6167. &nbsp;&nbsp;
Phone: <b>(08) 9419 6239</b> &nbsp;&nbsp;&nbsp;
Email: <a href="mailto:sales@tyresave.com.au">sales@tyresave.com.au</a>
</div>

<div class="logos">
<img src="kumho.jpg" alt="Kumho Tyres" /><br/>
<img src="hankook.jpg" alt="Hankook Tyres" /><br/>
<img src="bridgestone.jpg" alt="Bridgestone Tyres" /><br/>
</div>

</td></tr>

<tr><td colspan="3" align="center" valign="top" class="navbox">
<!-- navigation -->
<a class="nav" href="index.php">Home</a> 
<a class="nav" href="about.php">About Us</a> 
<a class="nav" href="services.php">Services</a> 
<a class="nav" href="quotation.php">Request Quotation</a> 
<a class="nav" href="contact.php">Contact Us</a>
</td></tr>

</table>
<!-- end header table -->
<!-- page body-->
<!-- site map page-->
<table border="0" width="100%" cellpadding="5" cellspacing="5">
<tr><td width="100%" align="left" valign="top">
<br/>
<div class="title1" align="center">Tyre Save Terms and Conditions</div>
<br/>
<div align="center">
<table border="0" cellpadding="0" cellspacing="0">
<tr><td align="left">
<br/>

Under Construction

<br/><br/>
</td></tr>
</table>
</div>
</td></tr>
</table>
<!-- end site map page-->
<!-- footer nav bar-->
<table border="0" width="100%" cellpadding="0" cellspacing="0">
<tr><td height="20" width="100%" align="center" valign="middle" style="background: #ff0000; text-align: center; font-size: 12px; color: #ffffff;">
<a class="navbot" href="index.php">Home</a> | 
<a class="navbot" href="about.php">About Us</a> | 
<a class="navbot" href="services.php">Services</a> | 
<a class="navbot" href="quotation.php">Free Consultation</a> | 
<a class="navbot" href="contact.php">Contact Us</a> | 
<a class="navbot" href="privacy.php">Privacy policy</a> | 
<a class="navbot" href="terms.php">Terms &amp; Conditions</a> | 
<a class="navbot" href="sitemap.php">Site map</a>
</td></tr>
</table>
<!-- end footer nav bar-->
<div class="cop" align="center">&copy; Tyre Save Medina Pty Ltd. All rights reserved. &nbsp;&nbsp;&nbsp; Please read our <a href="privacy.php">privacy policy</a>.
 &nbsp;&nbsp;&nbsp; ABN 42 146 315 924 &nbsp;&nbsp;&nbsp; Lic: MRB6078</div>
<!-- end border div -->
</div>
</body>
</html>